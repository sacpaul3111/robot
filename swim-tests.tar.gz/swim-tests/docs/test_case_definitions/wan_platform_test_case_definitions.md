# WAN Platform Test Cases
This document catalogs all platform-agnostic test cases desired with their estimated level of effort to develop.

## Prioritization Matrix

| Priority | Test Case Name                         | Level of Effort (Fibonacci) |
| -------- | -------------------------------------- | --------------------------- |
| 1        | BGP Neighbor State                     | 2                           |
| 2        | NAT Configuration (Pre/Post Compare)   | 2                           |
| 3        | FHRP State (Pre/Post Compare)          | 3                           |
| 4        | Routing Table State (Pre/Post Compare) | 5                           |
| 5        | Interface State (Pre/Post Compare)     | 2                           |

## Test Case Definitions

### BGP Neighbor State
#### Description:
Configured BGP neighbors are in their expected state

#### Acceptance Criteria:
- PASS if all configured BGP neighbors have an abstracted state of 'Established,' else FAIL

### NAT Configuration 
#### Description:
NAT intent is present in the configuration

#### Acceptance Criteria:
- PASS for all pre-maintenance checks, record abstracted NAT configuration (intent) 
- PASS for all post-maintenance checks that match pre-maintenance config/intent, else FAIL

### FHRP State
#### Description:
Pre-maintenance state matches post-maintenance state (HSRP and VRRP)

#### Acceptance Criteria:
- PASS for all pre-maintenance checks, record abstracted states (active/standby role, enabled interfaces, etc.)
- PASS when all post-maintenance states match pre-maintenance abstracted states, else FAIL

### Routing Table Comparison
#### Description:
Pre-maintenance state matches post-maintenance state for EBGP, IBGP, EIGRP, OSPF, RIP, and Static

#### Acceptance Criteria:
- PASS for all pre-maintenance checks, record abstracted routes and their origin
- PASS when all post-maintenance abstracted routes and their origin match pre-maintenance abstracted routes and their origin, else FAIL

### Interface State
#### Description:
All interfaces have the expected state after maintenance

#### Acceptance Criteria:
- PASS for all pre-maintenance checks, record interfaces and their abstracted states (up, down, shutdown)
- PASS when all post-maintenance interfaces states match their abstracted pre-maintenance states, else FAIL
