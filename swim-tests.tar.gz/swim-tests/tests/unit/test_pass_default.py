"""Default passing test"""


def test_pass_default():
    "Just a default passing test"
    assert True
