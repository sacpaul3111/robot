#!/bin/bash
# Set swim-tests specific environment variables
export global_workspace="${PWD}"
export global_ansible_verbosity="$(echo "${SWIM_WORKFLOW_VERBOSITY}" | awk -F"v" '{print NF-1}')" # Count the number of 'v' being passed to the script

export ANSIBLE_CONFIG="${PWD}/robot/resources/source/ansible/playbooks/ansible.cfg"
export SWIM_RESULTS_FOLDER="${RD_JOB_EXECID:=000000}/${SWIM_MAINTENANCE_PHASE}"
export SWIM_OUTPUT_XML_FILE_PATH="${SWIM_RESULTS_LOCAL_GIT_BASE_PATH}${SWIM_RESULTS_GIT_NAME}/${SWIM_RESULTS_FOLDER}/"
ansible-playbook robot/resources/source/ansible/playbooks/generate_inventory.yml "${SWIM_WORKFLOW_VERBOSITY}"
ansible-playbook -i robot/resources/source/ansible/playbooks/inventories/auto-gen_nautobot.yml -t clone --extra-vars="{'maintenance_phase':${SWIM_MAINTENANCE_PHASE}}" robot/resources/source/ansible/playbooks/git.yml "${SWIM_WORKFLOW_VERBOSITY}"
if [ "${SWIM_MAINTENANCE_PHASE}" == "post" ]; then
    robot --outputdir "${SWIM_RESULTS_LOCAL_GIT_BASE_PATH}/${SWIM_RESULTS_GIT_NAME}/${SWIM_RESULTS_FOLDER}" --listener robot/libraries/EmailListener.py --variable maintenance_phase:"${SWIM_MAINTENANCE_PHASE}" robot/tests/validate_wan_devices.robot || ( ansible-playbook -i robot/resources/source/ansible/playbooks/inventories/auto-gen_nautobot.yml -t commit --extra-vars="{'maintenance_phase':${SWIM_MAINTENANCE_PHASE}}" robot/resources/source/ansible/playbooks/git.yml "${SWIM_WORKFLOW_VERBOSITY}" && exit 1 )
else    
    robot --outputdir "${SWIM_RESULTS_LOCAL_GIT_BASE_PATH}/${SWIM_RESULTS_GIT_NAME}/${SWIM_RESULTS_FOLDER}" --variable maintenance_phase:"${SWIM_MAINTENANCE_PHASE}" robot/tests/validate_wan_devices.robot || ( ansible-playbook -i robot/resources/source/ansible/playbooks/inventories/auto-gen_nautobot.yml -t commit --extra-vars="{'maintenance_phase':${SWIM_MAINTENANCE_PHASE}}" robot/resources/source/ansible/playbooks/git.yml "${SWIM_WORKFLOW_VERBOSITY}" && exit 1 )
fi
ansible-playbook -i robot/resources/source/ansible/playbooks/inventories/auto-gen_nautobot.yml -t commit --extra-vars="{'maintenance_phase':${SWIM_MAINTENANCE_PHASE}}" robot/resources/source/ansible/playbooks/git.yml "${SWIM_WORKFLOW_VERBOSITY}"