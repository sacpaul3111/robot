Validate Platform Information
====================================

Role that performs testing for Inventory, Routing, and Interfaces for Versa FlexVNF and Cisco IOSXE Platforms
Utilizes TextFSM and commands on the device to normalize data into JSON Structures for pre/post testing.

Requirements
------------

None

Role Association and Varibles
---------------------------------

### `playbooks/playbook.yml`

`playbooks/playbook.yml` is the entrypoint into this role. It is called once for pre-checking/testing and once after the software upgrade for post checking/testing.

```yaml
---
# ...snip...
    - name: Validate Facts Pre-Maintenance
      ansible.builtin.include_role:
        name: validate
      vars:
        validate_maintenance_phase: pre
-------------
    - name: Validate Facts Post-Maintenance
      ansible.builtin.include_role:
        name: validate
      vars:
        validate_maintenance_phase: post
# ...snip...
```

### `{{ role_path }}/tasks/main.yml`
the ***main.yml*** is the file implicitly called to run the role. This task relies on the ansible_network_os variable to be set to diffirentiate between IOS-XE and Versa FlexVNF

```yaml
---
# ...snip...
    - name: Get Facts
      ansible.builtin.include_tasks: "{{ ansible_network_os }}/get_facts.yml"
# ...snip...
```

| Name                 | Required | Description                 |
|----------------------|----------|-----------------------------|
| ansible_network_os   | Yes      | Defines Device OS           |

## Dependencies
* **Playbook playbook.yml**

## Tasks Being Performed
* Gather Inventory, BGP Routing, and Interface statistics from IOS-XE/FlexVNF using Ansible facts and TextFSM
* Normalize data using .j2 templates, adhering to JSON Schema
* Validate normalized data against JSON Schema to ensure correct formatting
* Test against validated data to determine pass/fail


## Platform Specific Notes
* **IOS-XE**
    * IOS-XE has Ansible Module support and data is easily gathered using ansible.ios.ios and its submodules

* **Versa FlexVNF**
    * FlexVNF does not have an Ansible module, as such we utilize the RAW module. Additionally we SSH to port 2024 as it drops us directly into the CLI for the Versa FlexVNF instead of the Ubuntu bash shell. We need to do some additional data massaging here as a result of not being able to run a simple get_facts for our data.

Author Information
-------------------

```
WWT Automation
```