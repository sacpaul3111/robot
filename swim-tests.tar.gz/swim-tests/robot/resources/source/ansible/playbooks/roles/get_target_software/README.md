Get Target Software
====================================

This role executes a multi-step process in order to retrieve images from the central image repository and place them on the target network device.
Step 1 will grab the necessary software for the upgrade/downgrade and copy it from the specified central image repository onto the Ansible Controller.
Step 2 will grab the necessary software for the upgrade/downgrade and copy it from the Ansible Controller to the local device.


Requirements
------------

None

Role Association and Varibles
---------------------------------

### `playbooks/playbook.yml`

`playbooks/playbook.yml` is the entrypoint into this role. It is called once for pre-checking/testing and once after the software upgrade for post-checking/testing.

```yaml
---
# ...snip...
    - name: Perform Software Maintenance if Required
      when:
        - software_maintenance_required
        - software_actions.add.system_image is defined
        - software_actions.add.system_image
      block:
      ..........
        - name: Get Target Software
          ansible.builtin.include_role:
            name: get_target_software
# ...snip...
```

### `{{ role_path }}/tasks/main.yml`
the ***main.yml*** is the file implicitly called to run the role. This task relies on the several software image management variables gathered within the playbooks.

```yaml
---
- name: Get Target Software on Ansible Controller
  ansible.builtin.include_tasks: "get_target_software_controller.yml"

- name: Get Target Software on Network Device
  ansible.builtin.include_tasks: "{{ ansible_network_os }}/get_target_software_network_device.yml"

```

the ***main.yml*** file calls two separate tasks, one to grab the software and place it on to the controller and a second which utilizes the ***{{ ansible_network_os }}*** variable. This allows platform specific functions to take place.

### Operating System Specific Tasks

The ***{{ ansible_network_os }}*** folders both contain identical tasks.
The task get_target_software_network_device is implicitly called from the main.yml file
* **check_network_device_file_exists.yml**
* **get_network_device_md5_hash.yml**
* **get_target_software_network_device.yml**
* **{{ansible_network_os}}.yml**
```yaml
---
# ...snip flexvnf.yml...
    - name: Include FlexVNF Software Retrieval Tasks
     ansible.builtin.include_tasks: flexvnf.yml
     when:
        - software_platform is defined
        - software_platform == "flexvnf"
--------------------------------------------------
# ...snip get_target_software_network_device.yml...
    - name: Check If Target File Exists on Network Device
      ansible.builtin.include_tasks: check_network_device_file_exists.yml

    - name: Glean MD5 Hash of File on Network Device If It Exists
      ansible.builtin.include_tasks: get_network_device_md5_hash.yml
      when:
        - device_file_exists
# ...snip...
```

| Name                              | Required | Description                                                                                   |
|-----------------------------------|----------|-----------------------------------------------------------------------------------------------|
| ansible_network_os                | Yes      | Determines the type of OS for the network device |
| software_maintenance_required     | Yes      | Defines if Upgrade/Downgrade is required. Gathered in derive_software_actions                 |
| software_actions.add.system_image | Yes      | Defined by derive_software_actions. No user input required. Gathered using inventory var and host data |

## Dependencies
* **Playbook playbook.yml**

## Tasks Being Performed
* Determine whether or not the /tmp/swim folder exists on the automation controller node, create if it does not exist.
* Check central image repository for the specified software versions requested. Download if the file does not exist on controller
    * Grab the MD5 Hash of the file from the central image repository for checking against.
* Move into Platform Specific
    * See if the software file exists on device, check MD5 hash against central image repository's MD5 value.
    * If file doesnt exist, calculate free space on device, and ensure there is enough space to hold the new software image.
    * Push file to network device from controller as long as all checks pass.
        * Check MD5 hash here if download needed
    * Assert that MD5 hash on device matches what was gleaned from Nexus OSS


## Platform Specific Notes
* **IOS-XE**
    * None

* **Versa FlexVNF**
    * SSH port 2024 is used for CLI commands, but SSH port 22 is used for SCP protocol when pushing the file from Ansible to FlexVNF

Author Information
-------------------

```
WWT Automation
```