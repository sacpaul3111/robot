"""Example filter plugin which can be removed from project."""

import jmespath
from ansible.errors import AnsibleFilterError


class FilterFunctions:  # pylint: disable=too-few-public-methods,undefined-loop-variable,line-too-long,too-many-nested-blocks
    """Add functions in here.  Functions that don't start with _ will be imported into the playbook."""

    @staticmethod
    def filter_firmware_matrix(
        firmware_regex_matrix, system_rommon_maintenance_action, rommon_version, target_rommon_version
    ):
        """Filter to iterate over the software/rommon matrix and find all of its future steps."""
        matching_supported_path = []
        supported_paths = []
        supported_firmware_path = []
        match = "[?release == '{}']".format(target_rommon_version)  # pylint: disable=consider-using-f-string
        result = jmespath.search(match, firmware_regex_matrix)
        for supported_path in result:
            supported_path["supported_paths"] = [
                path.replace("\\", "") for path in supported_path.get("supported_paths", [])
            ]

        if system_rommon_maintenance_action == "upgrade":
            try:
                supported_path["supported_paths"].index(str(rommon_version))
                matching_supported_path.append(supported_path["release"])
            except Exception as error:
                raise AnsibleFilterError(error) from error

        if system_rommon_maintenance_action == "downgrade":
            try:
                supported_path["supported_paths"].index(str(rommon_version))
                matching_supported_path.append(supported_path["release"])
            except Exception as error:
                raise AnsibleFilterError(error) from error

        if matching_supported_path:
            supported_firmware_path = [
                {
                    "regex_match": matching_supported_path[0],
                    "starting_release": rommon_version,
                    "next_release": target_rommon_version,
                }
            ]
        else:
            next_step = rommon_version
            step_number = 1
            while next_step != target_rommon_version:
                for supported_paths in reversed(firmware_regex_matrix):
                    ### The second replace here is for wildcard handling in the firmware_matrix 16.x(1r) vs 16.9(1r)
                    ### Currently it just loops forever if the firmware has 16.x(1r)
                    supported_paths["supported_paths"] = [
                        path.replace("\\", "").replace("[0-9A-Za-z]+", "x")
                        for path in supported_paths.get("supported_paths", [])
                    ]
                    try:
                        supported_paths["supported_paths"].index(str(next_step))
                        matching_supported_path.append(supported_paths["release"])
                        next_step = supported_paths["release"]
                        supported_firmware_path.append(
                            {
                                "regex_match": supported_paths["release"],
                                "starting_release": rommon_version,
                                "next_release": next_step,
                                "step_number": step_number,
                            }
                        )
                        step_number = step_number + 1
                    except Exception as error:
                        raise AnsibleFilterError(error) from error
        return supported_firmware_path

    @staticmethod
    def filter_determine_software_platform(ansible_net_model, normalized_inventory):  # pylint: disable=R1710
        """Get software platform.

        Based on device model and the normalized inventory,
        this filter returns the device model in lowercase.
        """
        try:
            if (
                isinstance(normalized_inventory, dict)
                and "Standard PC" in normalized_inventory["model"]
                and normalized_inventory["serial"] == "Not Specified"
            ):
                get_model = "FLEXVNF"
            if isinstance(normalized_inventory, dict) and "ISRV" in normalized_inventory["model"]:
                get_model = "ISRV"
            if isinstance(normalized_inventory, dict) and isinstance(ansible_net_model, str):
                # This ternary expression picks up always the variable with greater length
                get_model = (
                    ansible_net_model
                    if len(ansible_net_model) >= len(normalized_inventory["model"])
                    else normalized_inventory["model"]
                )
            if isinstance(normalized_inventory, str) and isinstance(ansible_net_model, str):
                get_model = ansible_net_model

            model = ""
            match get_model:
                case "ISRV":
                    model = "isrv"
                case "FLEXVNF":
                    model = "flexvnf"
                case _ if "ISR" in get_model:
                    model = "isr"
                case _ if "C891" in get_model:
                    model = "c800"
                case _:
                    model = ""

            return model
        except Exception as error:
            raise AnsibleFilterError(error) from error

    @staticmethod
    def filter_determine_software_platform_storage_mount(software_platform):  # pylint: disable=R1710
        """Get storage mount.

        Filter returns storage mount based on software platform.
        """
        try:
            supported_platforms = {"isr": "bootflash", "c800": "flash"}
            return supported_platforms[software_platform]
        except Exception as error:
            raise AnsibleFilterError(error) from error

    # pylint: disable=too-many-locals,too-many-branches
    @staticmethod
    def filter_get_software_actions(software_matrix, swim_params, os_type, device_model):
        """Get Software actions.

        This filter works with version 3 of software matrix,
        the current versions gathered through ansible facts are used for querying,
        the software matrix to match the software actions based on the desired target version.
        """
        try:
            matrix_version = "v3"
            matrix_data = software_matrix[matrix_version][os_type][device_model]
            software_actions = {}
            target_version = {
                "type": swim_params["target_version"]["type"],
                "version": swim_params["target_version"]["version"],
            }
            software_matrix_item = {}
            for data in matrix_data["upgrade_paths"]:
                total_match = True
                for key in data["current_version"]:
                    if key in swim_params["current_versions"]:
                        if isinstance(data["current_version"][key], list):
                            if swim_params["current_versions"][key] not in data["current_version"][key]:
                                total_match = False
                if total_match:
                    software_matrix_item = data
            if software_matrix_item:
                for item in software_matrix_item["target_versions"]:
                    key = item.get(target_version["type"], False)
                    if key and key == target_version["version"]:
                        image_map = matrix_data["release_image_map"]
                        software_actions = []
                        for action in item["actions"]:
                            if action["type"] not in image_map:
                                raise AnsibleFilterError(
                                    f"Firmware Type ('{action['type']}') not available in release_image_map"
                                )

                            if action["release"] not in image_map[action["type"]]:
                                raise AnsibleFilterError(
                                    f"Release Version ('{action['release']}') not available in release_image_map"
                                )

                            # fmt: off
                            software_actions.append({
                                **action,
                                "image": image_map[action["type"]][action["release"]]
                            })
                            # fmt: on
            return software_actions
        except Exception as error:
            raise AnsibleFilterError(error) from error


class FilterModule:  # pylint: disable=too-few-public-methods
    """Export all functions from class FilterFunctions that start with filter to Ansible.

    `filter_stars` will be `stars` when used in Ansible.
    You do not need to edit this class.
    """

    def filters(self):
        """Return list of filters and corresponding functions to Ansible."""
        return {
            x.replace("filter_", ""): getattr(FilterFunctions, x)
            for x in dir(FilterFunctions)
            if x.startswith("filter_")
        }
