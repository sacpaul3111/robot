"""Edit this file for your basic python script."""


def main():
    """Put main code here."""
    print("Hello World!")


if __name__ == "__main__":
    main()
