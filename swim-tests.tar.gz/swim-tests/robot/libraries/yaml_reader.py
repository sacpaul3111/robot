"""This module reads the software matrix file and returns software images and device upgrade paths."""

import itertools
import os
from pprint import pprint

import yaml
from gitlab import GitLabAPI  # pylint: disable=import-error


def get_software_matrix():
    """Reads the software matrix file and returns the content as a dictionary."""
    access_token = os.environ.get("SWIM_SOFTWARE_MATRIX_REPO_TOKEN")
    project_id = os.environ.get("SWIM_SOFTWARE_MATRIX_REPO_ID")
    filename = (
        os.environ.get("SWIM_SOFTWARE_MATRIX_FILENAME").replace(".", "%2E").replace("/", "%2F").replace("_", "%5F")
    )
    gitlab = GitLabAPI(access_token=access_token, project_id=project_id)
    raw_file_content = gitlab.retrieve_raw_file(filename)
    converted_content = yaml.safe_load(raw_file_content)
    return converted_content


def get_software_release_images():
    """Reads the software matrix file and returns a list of software images."""
    data = {}
    data["software_matrix"] = get_software_matrix()

    software_images = []
    if "software_matrix" in data and "v3" in data["software_matrix"]:
        for software_section in data["software_matrix"]["v3"].values():
            for device_details in software_section.values():
                if "release_image_map" in device_details:
                    for software_map in device_details["release_image_map"].values():
                        software_images.extend(software_map.values())
    pprint(software_images)
    return software_images


# pylint: disable=too-many-locals,too-many-nested-blocks
def get_device_upgrade_path():
    """Reads the software matrix file and returns a dictionary of device upgrade paths."""
    data = {}
    data["software_matrix"] = get_software_matrix()
    devices_upgrade_info = {}

    if "software_matrix" in data and "v3" in data["software_matrix"]:
        for software_type in data["software_matrix"]["v3"].keys():
            for device, device_data in data["software_matrix"]["v3"][software_type].items():
                device_key = f"{software_type},{device}"
                parts = device_key.split(",")
                device_type = parts[0]
                device_model = parts[1]

                if device_key not in devices_upgrade_info:
                    devices_upgrade_info[device_key] = {
                        "device_type": device_type,
                        "device_model": device_model,
                        "upgrade_details": [],
                    }

                if "upgrade_paths" in device_data:
                    for upgrade in device_data["upgrade_paths"]:
                        version_combinations = generate_version_combinations(upgrade.get("current_version", {}))
                        for current_versions in version_combinations:
                            # Simplify current_versions to not use lists
                            simplified_current_versions = {
                                key: value[0] if isinstance(value, list) and len(value) == 1 else value
                                for key, value in current_versions.items()
                            }
                            # Process each target_version separately
                            for target in upgrade.get("target_versions", []):
                                simplified_target_versions = {
                                    key: value for key, value in target.items() if key != "actions"
                                }
                                upgrade_detail = {
                                    "current_versions": simplified_current_versions,
                                    "target_versions": simplified_target_versions,
                                }
                                devices_upgrade_info[device_key]["upgrade_details"].append(upgrade_detail)
                else:
                    print(f"No upgrade paths found for {software_type} device {device_model}")

    pprint(devices_upgrade_info)
    return devices_upgrade_info


def generate_version_combinations(versions):
    """Generates all possible combinations of versions for a device."""
    keys, values = zip(*versions.items())
    single_combinations = []
    for product in itertools.product(*[[(k, v) for v in vs] for k, vs in zip(keys, values)]):
        formatted_dict = {}
        for key, value in product:
            formatted_dict[key] = value if not isinstance(value, list) else value[0] if len(value) == 1 else value
        single_combinations.append(formatted_dict)
    return single_combinations


if __name__ == "__main__":
    print(get_software_matrix())
