"""Utility functions for interacting with the GitLab API."""

import os
import requests
from robot.api import logger


class GitLabAPI:  # pylint: disable=too-few-public-methods
    """Class for interacting with the GitLab API."""

    def __init__(self, base_url=None, project_id=None, access_token=None):
        """Initialize the GitLabAPI instance."""
        self.base_url = base_url or os.environ.get("SWIM_GITLAB_BASE_URL")
        self.project_id = project_id or os.environ.get("SWIM_GITLAB_PROJECT_ID")
        self.access_token = access_token or os.environ.get("SWIM_GITLAB_ACCESS_TOKEN")
        if os.environ.get("SWIM_ENVIRONMENT") == "prod":
            self.branch = "master"
        else:
            self.branch = "develop"

        self.branch = os.environ.get("SWIM_SOFTWARE_MATRIX_BRANCH_OVERRIDE", self.branch)

    def retrieve_raw_file(self, file_path):
        """Retrieve the raw contents of a file from a GitLab repository."""
        api_url = f"https://{self.base_url}/api/v4/projects/{self.project_id}/repository/files/{file_path}/raw?ref={self.branch}"
        logger.debug(f"Retrieving raw file from: {api_url}")
        headers = {"Authorization": f"Bearer {self.access_token}"}

        try:
            response = requests.get(api_url, headers=headers, timeout=10)
            response.raise_for_status()
            if response.text is None:
                raise requests.exceptions.RequestException("Response is empty")
            logger.info("Raw file retrieved successfully.")
            return response.text
        except requests.exceptions.RequestException as error:
            logger.error(f"Failed to retrieve raw file: {error}")
            return None
