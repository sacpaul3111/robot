# pylint: disable=too-many-arguments
"""Module providing a function to run ansible playbook using ansible_runner."""
import logging
import ansible_runner


log = logging.getLogger(__name__)


def run_ansible(
    playbook: str,
    inventory: str,
    extra_vars: dict = None,
    verbosity=1,
    private_data_dir: str = "/some_dir/ansible",
    ansible_tags=None,
    stdout_callback: str = "yaml",
    **kwargs,
) -> None:
    """Run an ansible playbook using ansible-runner.

    :param playbook: name of the playbook to run
    :type playbook: str
    :param extra_vars: dictionary of key:value pairs to pass as extra_vars, defaults to None
    :type extra_vars: t.Dict, optional
    :param private_data_dir: directory to use as private dir for ansible runner,
        defaults to "/tom/ansible/runner"
    :type private_data_dir: str, optional
    :param verbosity
    : Ansible verbosity level, defaults to 1
    :type verbosity: int, optional
    :param stdout_callback
    : Ansible stdout_call type, defaults to 'default' (JSON-valid representation)
    :type stdout_callback: str, optional
    :return: return code, status and either stats or stdout
    :type: tuple
    """
    if extra_vars is None:
        extra_vars = {}

    if ansible_tags is None:
        ansible_tags = []

    runner_opts = {
        "playbook": playbook,
        "inventory": inventory,
        "extravars": extra_vars,
        "verbosity": verbosity,
        "private_data_dir": private_data_dir,
        "tags": ansible_tags,
    }

    if kwargs:
        runner_opts.update(**kwargs)

    runner_config = ansible_runner.runner_config.RunnerConfig(**runner_opts)
    runner_config.prepare()

    if stdout_callback is not None:
        # Set up the callback type to 'yaml' for awx display
        runner_config.env["ANSIBLE_STDOUT_CALLBACK"] = stdout_callback
        runner_config.env["AWX_DISPLAY_STDOUT_CALLBACK"] = stdout_callback

    runner = ansible_runner.runner.Runner(config=runner_config)
    result = runner.run()

    status, _ = result

    if status == "failed":
        log.error("Playbook %s was not executed successfully.", playbook)
    return runner
