# pylint: disable=too-many-arguments, invalid-name, too-many-instance-attributes, too-many-locals, import-error
"""Module: EmailListener.

This module defines an EmailListener class that can be used as a listener in
Robot Framework test execution.  It provides functionality to send email
reports with test results and other relevant information.

Usage:
    To use this module, instantiate the EmailListener class and attach it to
    the Robot Framework test execution.
"""

import os
import smtplib
import math
import datetime

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import xml.parsers.expat

import defusedxml.minidom


class EmailListener:
    """A Robot Framework listener for sending email reports with test results.

    This listener tracks test execution and sends an email report with the test results
    once the test execution is complete.

    Usage:
        Instantiate the EmailListener class and attach it to the Robot Framework test execution.

    Attributes:
        ROBOT_LISTENER_API_VERSION (int): The version of the Robot Framework listener API supported
        by this class.

    """

    ROBOT_LISTENER_API_VERSION = 2

    def __init__(self):
        """Initialize the EmailListener object.

        Sets up the initial state of the EmailListener object.
        """
        self.total_tests = 0
        self.passed_tests = 0
        self.failed_tests = 0
        self.test_results = []
        self.send_email_flag = False
        self.smtp = None
        self.subject = None
        self.send_from = None
        self.send_to = None
        self.send_cc = None
        self.pre_runner = 0
        self.start_time = datetime.datetime.now().time().strftime("%H:%M:%S")
        self.date_now = None
        self.test_count = None
        self.end_time = None
        self.total_time = None
        self.suite_name = None

    def start_suite(self, name, attrs):
        """Called when a test suite starts.

        Args:
            name (str): The name of the test suite.
            attrs (dict): A dictionary containing attributes of the test suite.

        """
        # Fetch email details only once
        if self.pre_runner == 0:
            self.send_email_flag = os.getenv("SEND_EMAIL")
            self.smtp = os.getenv("SMTP")
            self.subject = os.getenv("SUBJECT")
            self.send_from = os.getenv("FROM")
            self.send_to = os.getenv("TO")
            self.send_cc = os.getenv("CC")
            self.suite_name = name

            self.pre_runner = 1

            self.date_now = datetime.datetime.now().strftime("%Y-%m-%d")

        self.test_count = len(attrs["tests"])

    def end_test(self, name, attrs):
        """Called when a test suite ends.

        Args:
            name (str): The name of the test suite.
            attrs (dict): A dictionary containing attributes of the test suite.

        """
        if self.test_count != 0:
            self.total_tests += 1

        if attrs["status"] == "PASS":
            self.passed_tests += 1
        else:
            self.failed_tests += 1
        self.test_results.append({"name": name, "status": attrs["status"]})

    def close(self):
        """Close the email listener and send the final report.

        This method should be called at the end of the test execution to finalize the email report
        """
        self.end_time = datetime.datetime.now().time().strftime("%H:%M:%S")
        # fmt: off
        self.total_time = (
            datetime.datetime.strptime(self.end_time, "%H:%M:%S") - datetime.datetime.strptime(
                self.start_time, "%H:%M:%S")
        )
        # fmt:on
        xml_dir = os.getenv("SWIM_OUTPUT_XML_FILE_PATH")
        xml_path = xml_dir + "output.xml"
        rundeck_job_id = os.getenv("RD_JOB_EXECID", "000000")
        hostname_list = extract_info_from_xml(xml_path, "hostname_list").split(",")
        serial_list = extract_info_from_xml(xml_path, "serial_list").split(",")
        ip_list = extract_info_from_xml(xml_path, "ip_list").split(",")
        model_list = extract_info_from_xml(xml_path, "model_list").split(",")
        platform_list = extract_info_from_xml(xml_path, "platform_list").split(",")
        software_list = extract_info_from_xml(xml_path, "software_list").split(",")

        inventory_summary = [
            {
                "hostname": hostname,
                "serial": serial,
                "ip": ip,
                "model": model,
                "platform": platform,
                "software": software,
            }
            for hostname, serial, ip, model, platform, software in zip(
                hostname_list, serial_list, ip_list, model_list, platform_list, software_list
            )
        ]

        send_email(
            self.send_email_flag,
            self.subject,
            self.smtp,
            self.send_from,
            self.send_to,
            self.send_cc,
            self.total_tests,
            self.passed_tests,
            self.failed_tests,
            math.ceil(self.passed_tests * 100.0 / self.total_tests),
            self.date_now,
            self.total_time,
            self.test_results,
            xml_path,
            rundeck_job_id,
            inventory_summary,
            self.suite_name,
        )


def extract_info_from_xml(xml_path, info_name):
    """Extract information from an XML file.

    This method parses the specified XML file located at xml_path and extracts
    information based on the provided info_name.

    Args:
        xml_path (str): The path to the XML file.
        info_name (str): The name of the information to extract from the XML.

    Returns:
        str or None: The extracted information, or None if the information is not found.

    """
    try:
        dom_tree = defusedxml.minidom.parse(xml_path)
        root = dom_tree.documentElement

        all_text = root.toxml()

        if info_name in all_text:
            info_index = all_text.find(info_name)
            info_start = all_text.find(":", info_index)
            if info_start != 1:
                info_end = all_text.find("\n", info_start)
                info = all_text[info_start + 1 : info_end].strip()
                return info
        return None
    except (xml.parsers.expat.ExpatError, defusedxml.ElementTree.ParseError) as error:
        print(f"Error parsing XML file: {error}")
        return None


def send_email(
    send_email_flag,
    subject,
    smtp,
    from_user,
    send_to,
    send_cc,
    total,
    passed,
    failed,
    percentage,
    exe_date,
    elapsed_time,
    test_results,
    xml_path,
    rundeck_job_id,
    inventory_summary,
    suite_name,
):
    """Send an email with test results.

    Args:
        send_email_flag (bool): Flag indicating whether to send the email.
        subject (str): The subject of the email.
        smtp (str): SMTP server address.
        from_user (str): Sender's email address.
        send_to (str): Recipient's email address.
        send_cc (str): CC email address.
        total (int): Total number of tests.
        passed (int): Number of tests passed.
        failed (int): Number of tests failed.
        percentage (float): Percentage of tests passed.
        exe_date (str): Execution date.
        elapsed_time (datetime.timedelta): Total execution time.
        test_results (list): List of test results.
        xml_path (str): Path to the XML file.
        rundeck_job_id (str): Rundeck job ID.
        inventory_summary (list): List of dictionary containing device information.
        suite_name (str): Name of the test suite.
    """
    # Convert string "False" to boolean False
    if send_email_flag.lower() == "false":
        send_email_flag = False
    else:
        # Convert other values to boolean True
        send_email_flag = bool(send_email_flag)

    if send_email_flag is True:
        server = smtplib.SMTP(smtp)

        msg = MIMEMultipart()
        msg["Subject"] = subject

        msg["From"] = from_user
        msg["To"] = send_to
        msg["Cc"] = send_cc
        to_addrs = [send_to] + [send_cc]
        msg.add_header("Content-Type", "text/html")

        # Prepare email content
        email_content = (
            """
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <title>Automation Status</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0 " />
            <style>
                body {
                    background-color:#F2F2F2;
                }
                body, html, table,span,b {
                    font-family: Courier New;
                    font-size: 14px;
                }
                .pastdue { color: crimson; }
                table {
                    border: 1px solid silver;
                    padding: 6px;
                    margin-left: 30px;
                    width: 300px;
                }
                tbody {
                    text-align: center;
                }
                td {
                    height: 25px;
                }
                .dt-buttons {
                    margin-left: 30px;
                }
            </style>
        </head>
        <body>
        <span>Hi Team,<br><br>
        Please see the latest test execution status for suite """
            + suite_name
            + """.<br><br>
        Test Result(s):<br><br></span>
            <table>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Test Name</td>
                   <td style="background-color: #DCDCDC;text-align: center;">Status</td>

                </tr>
        """
        )

        for test_result in test_results:
            if test_result["status"] == "PASS":
                cell_style = 'style="text-align: center; background-color: lightgreen;"'
            else:
                cell_style = 'style="text-align: center; background-color: crimson;"'

            email_content += f"""
                <tr>
                    <td {cell_style}>{test_result['name']}</td>
                    <td {cell_style}">{test_result['status']}</td>
                </tr>
            """

        email_content += f"""
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Rundeck Job ID</td>
                   <td style="text-align: center;">{rundeck_job_id}</td>
                </tr>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Total</td>
                   <td style="text-align: center;">{total}</td>
                </tr>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Pass</td>
                   <td style="text-align: center;">{passed}</td>
                </tr>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Fail</td>
                   <td style="text-align: center;">{failed}</td>
                </tr>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Pass Percentage</td>
                   <td style="text-align: center;">{percentage}</td>
                </tr>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Execution Date</td>
                   <td style="text-align: center;">{exe_date}</td>
                </tr>
                <tr>
                   <td style="background-color: #DCDCDC;text-align: center;">Duration</td>
                   <td style="text-align: center;">{elapsed_time}</td>
                </tr>
                </tbody>
            </table>
        """
        email_content += """
            <br><br>
            Device(s) Under Test:<br><br></span>
                <table>
                    <tr>
                    <td style="background-color: #DCDCDC;text-align: center;">Hostname</td>
                    <td style="background-color: #DCDCDC;text-align: center;">Serial Number</td>
                    <td style="background-color: #DCDCDC;text-align: center;">IP Address</td>
                    <td style="background-color: #DCDCDC;text-align: center;">Model Number</td>
                    <td style="background-color: #DCDCDC;text-align: center;">Platform</td>
                    <td style="background-color: #DCDCDC;text-align: center;">Software Version</td>
                    </tr>
        """

        inventory_cell_style = 'style="text-align: center;"'
        for device in inventory_summary:
            email_content += f"""
                <tr>
                    <td {inventory_cell_style}>{device['hostname']}</td>
                    <td {inventory_cell_style}">{device['serial']}</td>
                    <td {inventory_cell_style}>{device['ip']}</td>
                    <td {inventory_cell_style}">{device['model']}</td>
                    <td {inventory_cell_style}>{device['platform']}</td>
                    <td {inventory_cell_style}">{device['software']}</td>
                </tr>
            """
        email_content += """
                    </tbody>
                </table>
            <span><br>Regards,<br>Automation Team</span>

        </body></html>
        """

        msg.attach(MIMEText(email_content, "html"))

        with open(xml_path, "rb") as attachment:
            part = MIMEBase("application", "xml")
            part.set_payload(attachment.read())

        encoders.encode_base64(part)
        part.add_header("Content-Disposition", "attachment; filename= ansible_log.txt")
        msg.attach(part)

        server.sendmail(from_user, to_addrs, msg.as_string())
